<div class="container">
	<!--footer start from here-->
	<footer>
		<div class="container">
			<div class="row">

				<div class="col-md-3 col-sm-6 paddingtop-bottom">
					<h6 class="heading7">Недвижимость</h6>
					<ul class="footer-ul">
						<li><a href="#"> Каталог обьектов</a></li>
						<li><a href="#"> Новострои</a></li>
						<!-- <li><a href="#"> Terms & Conditions</a></li>
						<li><a href="#"> Client Gateway</a></li>
						<li><a href="#"> Ranking</a></li>
						<li><a href="#"> Case Studies</a></li>
						<li><a href="#"> Frequently Ask Questions</a></li> -->
					</ul>
				</div>
				<div class="col-md-3 col-sm-6 paddingtop-bottom">
					<h6 class="heading7">Доминанта</h6>
					<ul class="footer-ul">
						<li><a href="#"> О компании</a></li>
						<li><a href="#"> Карьера</a></li>
						<!-- <li><a href="#"> Terms & Conditions</a></li>
						<li><a href="#"> Client Gateway</a></li>
						<li><a href="#"> Ranking</a></li>
						<li><a href="#"> Case Studies</a></li>
						<li><a href="#"> Frequently Ask Questions</a></li> -->
					</ul>
				</div>
				<div class="col-md-3 col-sm-6 paddingtop-bottom">
					<h6 class="heading7">Новости</h6>
					<ul class="footer-ul">
						<li><a href="#"> Все</a></li>
						<li><a href="#"> Доминанты</a></li>
					<!-- 	<li><a href="#"> Terms & Conditions</a></li>
						<li><a href="#"> Client Gateway</a></li>
						<li><a href="#"> Ranking</a></li>
						<li><a href="#"> Case Studies</a></li>
						<li><a href="#"> Frequently Ask Questions</a></li> -->
					</ul>
				</div>
				<div class="col-md-3 col-sm-6 paddingtop-bottom">
					<h6 class="heading7">Контакты</h6>
					<ul class="footer-ul">
						<li><a href="#"> Контакты</a></li>
						<li><a href="#"> Отзывы</a></li>
					<!-- 	<li><a href="#"> Terms & Conditions</a></li>
						<li><a href="#"> Client Gateway</a></li>
						<li><a href="#"> Ranking</a></li>
						<li><a href="#"> Case Studies</a></li>
						<li><a href="#"> Frequently Ask Questions</a></li> -->
					</ul>
				</div>


			</div>

			<!-- down -->
			<div class="col-sm-12 paddingtop-bottom text-center">
			<h6 class="heading7_description">Подписывайтесь на наши группы в социальных сетях!</h6>
			

                <a href="https://vk.com/club12128325"><img class="scale" src="img/verstka/vk.png" alt="vk"></a>
                <a href="https://www.facebook.com/pages/Dominanta-D/127233184113790"><img class="scale" src="img/verstka/facebook.png" alt="facebook"></a>
                <a href="https://www.youtube.com/channel/UCiUD9d9dDxQyd7KLqzIdtYw"><img class="scale" src="img/verstka/youtube.png" alt="youtube"></a>
            


			</div>




		</div>
	</footer>
	<!--footer start from here-->

	<div class="copyright">
		<div class="container">
			<div class="col-md-6">
				<p>© Доминанта, 2017г. Все права защищены. </p>
			</div>
			<div class="col-md-6">
   <!--    <ul class="bottom_ul">
        <li><a href="#">webenlance.com</a></li>
        <li><a href="#">About us</a></li>
        <li><a href="#">Blog</a></li>
        <li><a href="#">Faq's</a></li>
        <li><a href="#">Contact us</a></li>
        <li><a href="#">Site Map</a></li>
    </ul> -->
</div>
</div>
</div>

<div class="footer-menu">
                    <a href="/privacy">Политика конфиденциальности</a>
                    <a href="/terms">Условия использования</a>
                    <a href="#">Юридическая информация</a>
                    <a href="/index.php?route=information/sitemap">Карта сайта</a>
                </div>


</div> <!-- /container -->


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script>window.jQuery || document.write('<script src="docs/assets/js/vendor/jquery.min.js"><\/script>')</script>
    
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="docs/assets/js/ie10-viewport-bug-workaround.js"></script>

			<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDB2kS5Y_XmTaIwC2h0uFxml1SDnrqYqnw&callback=initMap"
			async defer>
				
        


			</script>

<script>
	
  var map;
function initMap() {
  map = new google.maps.Map(document.getElementById('map'), {
    center: {lat: -34.397, lng: 150.644},
    zoom: 8
  });
}

	
</script>


</body>
</html>