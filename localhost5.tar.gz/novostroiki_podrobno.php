<?php
include_once 'includes/header.php';
include_once 'includes/carusele.php';
 include_once 'includes/fullscreenfilter.php';
?>



        <!-- vertical carusele -->
		  <link href="css/thumbs2.css" rel="stylesheet" />
    <link href="css/thumbnail-slider.css" rel="stylesheet" type="text/css" />
    <script src="libs/thumbnail-slider.js" type="text/javascript"></script>


<style type="text/css">
	<?php
	include_once 'css/novostroiki_podrobno.css';
	//include_once 'libs/jquery.ad-gallery.css';
	?>

</style>
<script type="text/javascript">
	<?php
	include_once 'js/novostroiki_podrobno.js';
	?>

</script>


   

<!-- <script type="text/javascript" src="libs/adg-galery/jquery.ad-gallery.js"></script> -->
<!-- <div class="container">
  <div class="row">
    <div class="col-*-*"></div>
  </div>
  <div class="row">
    <div class="col-*-*"></div>
    <div class="col-*-*"></div>
    <div class="col-*-*"></div>
  </div>
  <div class="row">
    ...
  </div>
</div>
-->


<!-- breadcrumb -->
<div class="container">
	<div class="row">
		<ol class="breadcrumb">
			<li class="breadcrumb-item"><a  class="clear_link"  href="">Доминанта</a></li>
			<li class="breadcrumb-item"><a  class="clear_link"  href="">Library</a></li>
			<li class="breadcrumb-item active">Поиск</li>
		</ol>
		
		
	</div>
</div>
<!-- end breadcrumb -->

<!-- sortline -->
<div class="container sortline">
	<div class="row" style="    font-family: 'Open Sans Condensed', sans-serif;">
	 <div class="col-sm-12 col-md-4" style="padding: 0;">
	 <div class="btn btn-block fill_button">

	 <span class="buy_text">Реализовано м<sup>2</sup></span>
	
	<span class="clock"></span>
	  <span class="buy_text"> м<sup>2</sup></span>	
	 </div> 	
	 


	 </div>
	 <div class="col-sm-6 col-md-2">
	 	 <div class="btn btn-block fill_button">

	 <span class="buy_text">Приморский</span>		
	 </div> 
	 </div>
	 <div class="col-sm-6 col-md-2">
	 	 	 <div class="btn btn-block fill_button">

	 <span class="buy_text">Киевский</span>		
	 </div> 
	 </div>
	 <div class="col-sm-6 col-md-2">
	 	 	 <div class="btn btn-block fill_button">

	 <span class="buy_text">Малиновский</span>		
	 </div> 
	 </div>
	 <div class="col-sm-6 col-md-2">
	 	 	 <div class="btn btn-block fill_button">

	 <span class="buy_text">Cуворовский</span>		
	 </div> 
	 </div>
	

	</div>

</div>
<!-- end sortline -->

<!-- button -->
<div class="container sortline" style="padding-top: 1em;">
	<div class="row" style="    font-family: 'Open Sans Condensed', sans-serif;">
	 <div class="col-sm-12 pull-left" style="padding: 0;">
	 <div class="btn btn-default ">
         Вернуться к списку
	 </div> 	
	 </div>

 <div class="col-sm-12 pull-left">
	 <h1 class="title_room">Продажа двухкомнатной квартиры в Одессе по ул. Балковская</h1>	
	 </div>	 

<div class="col-sm-12" style="    padding-bottom: 1em;">
		<div class="col-sm-6"><a href="" class="clear_link"><i class="icon-like "></i>Добавить в избранное</a></div>
	


</div>

</div>
<!-- end button -->


<!-- main wrap content -->
<div class="container wrap_content">

	<div class="row">
		<div  class="col-sm-12 col-md-12 col-lg-9" style="padding-right: 0; padding-left: 0; ">

			<div class="wrap_catalog  "> 
























<div class="container">
    <div class="row">
		<div class="col-md-9 col-lg-7 nodecor">
			<!-- artigo em destaque -->
			<div class="featured-article main_image">
				<a href="#">
					<img src="http://placehold.it/350x150" alt="" class="thumb">
				</a>
<!-- 				<div class="block-title">
					<h2>Lorem ipsum dolor asit amet</h2>
					<p class="by-author"><small>By Jhon Doe</small></p>
				</div> -->
			</div>
			<!-- /.featured-article -->
		</div>
		<div class="col-md-3 col-lg-3">



       <div style="">
            <div id="thumbs2">
                <div class="inner">
                    <ul>
                        <li>
                           <!--  <a href="/">
                                <span class="thumb" style="background-image:url(img/1.jpg)">
                                    This slide demonstrates how to link the thumbnail image to another web page.
                                </span>
                            </a> -->
                        </li>


                        <?php foreach (range(0, 10) as $key => $value) { ?>
                        <li>
                            <a class="thumb" href="/img/verstka/img2-500x350.jpg"></a>
                        </li>

                        <?php } ?>
                        
                  
                    </ul>
                </div>
            </div>
        </div>



 
		</div>
		<div class="col-lg-2"></div>
	</div>
	</div>


		<div class="col-sm-12">
			<h2 class=""><a href="" class="clear_link"> Новострои Одессы ЖК 'Острова'</a></h2>
		</div>
		<div class="col-sm-12" style="text-indent: 0.5em;">
			<div>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Totam voluptas dignissimos ut corrupti dolores, maiores provident a debitis ipsam deserunt harum cumque hic unde, tempore accusamus aut similique. Qui, ducimus.</div>
			<div>Natus eius aperiam commodi, rem dolore perspiciatis minima ducimus! Similique repellendus voluptatibus eligendi reiciendis omnis suscipit cupiditate sint possimus sapiente ratione consectetur explicabo impedit deleniti dignissimos porro non, molestias vitae.</div>
			<div>Aperiam officia consequatur enim, totam, est velit odio officiis excepturi optio illum magnam illo distinctio culpa porro! Eaque dolores dolorum aspernatur consequatur beatae accusantium, fugiat. Quam laboriosam fugit hic alias.</div>
			<div>Nisi delectus itaque ullam veniam doloremque eum repellat labore non et rerum inventore molestias, voluptatibus reiciendis, maiores cumque laborum in fugiat harum provident iure, commodi? Ut quam consectetur alias eum.</div>
			<div>Eaque ipsum animi corporis magni ducimus rerum quos, distinctio placeat saepe tenetur, ratione eos similique? Veniam iste reprehenderit sapiente, perspiciatis cupiditate sit consequatur quasi quas repellendus neque vero quia atque!</div>
			<div>Nemo ullam ipsam nulla. Rerum voluptate dolor temporibus repellat officiis ipsum nihil minus. Minus saepe voluptate, laborum similique id, autem eveniet totam quasi architecto deleniti perferendis. Consequatur harum, nesciunt excepturi.</div>
 <br>
			 <h4 class="some_info">
				Мадагаскар 1 дом сдан, Мадагаскар 2 дом сдан
			</h4>

		</div>
           

           <div class="col-sm-6">
       <br>
           <p class="broni_info some_info">
Отдел бронирования
    </p>    	
  <table class="table">

    <tbody>
      <tr>
        <td>Адресс</td>
        <td>Minus saepe voluptate, laborum similique</td>
        
      </tr>
      <tr>
        <td>Телефон</td>
        <td>
                <div class="tel">1234567989</div>
                                <div class="tel">1234567989</div>
                                                <div class="tel">1234567989</div>
                                                                <div class="tel">1234567989</div>
        </td>   
      </tr>

       <tr>
        <td>E-mail</td>
        <td>demo@sobcak.com</td>   
      </tr>
  

    </tbody>
  </table>

           </div>
           <div class="col-sm-6">
           	
 <div class="wrap_btn">
           	<div class="btn btn-block fill_button">

	 <span class="buy_text">Получить подробную консультацию у нашего специалиста</span>		
	 </div>
	 </div>
           </div>

          
	









			</div> 
			<!-- end wrap content -->




		</div>


		<!-- side bar -->
		<div class="col-sm-12 col-md-12 col-lg-3 text-center" style="    padding: 0;">
			<div class="row">



				<div class="left-site-bar">

 




					<div class="news-box wrap_gogle_map news-title-obj">
					<div class="title_ibj">На карте</div>
					
					<div>&nbsp;</div>
						<div id="map"></div>
						<div class="pull-left">
							<a href="" class="clear_link"><i class="icon-map"></i>На большой карте</a>
						</div>



					</div> 

					<!-- end news box -->

					<div class="news-box viewed_rooms hide">
						<div class="news-title"><a href="">Недавно смотрели</a> </div>


           <?php
           foreach (range(0,4) as $key => $value) { ?>
         			<a href="" class="clear_link">
							<div class="thumbnail  span4 clear_border">
								<img src="http://placehold.it/120x160" alt="">
								<div class="caption">
									<h4 class="clear_link">85 000 $</h4>
									<p>г. Одесса</p>
									<p>ул. Балковская 95а</p>
									<!-- <p><a href="" class="clear_link">Вернуться</a></p> -->
								</div>
							</div>
						</a>
         <?php  }?>			



					</div> 




				</div>



			</div>


		</div>
		<!-- end left sidebar -->







	</div> 
	<!-- end row -->
</div>
<!--end  main wrap content -->

































<div class="container">
	<!-- Example row of columns -->
	<div class="row">

		<div id="catalog5"  >
			<div class="catalog-title-about"><span>Наши партнеры</span></div>

			<div class="catalog">


				<div class="col-md-12">
					<br>
					<div id="myCarousel5" class="carousel vertical slide" data-ride="carousel" >
						<!-- Indicators -->
						<ol class="carousel-indicators">
							<li data-target="#myCarousel5" data-slide-to="0" class="active"></li>
							<li data-target="#myCarousel5" data-slide-to="1"></li>
							<li data-target="#myCarousel5" data-slide-to="2"></li>
							<li data-target="#myCarousel5" data-slide-to="3"></li>
						</ol>

						<!-- Wrapper for slides -->
						<div class="carousel-inner" role="listbox">


							<?php
							foreach (range(0, 4) as $key => $value) {?>
							<div class="item <?= $value==0?'active':'';?> ">
								<div class="wrap_carousele">




									<?php foreach (range(0, 2) as $k => $v) {?>


									<div class="col-sm-4 clear_padding wrap_item partner_padding">
										<div class="col-sm-12 clear_padding">
											<div class="thumbnail  span5">
												<a href="">	<img class="span3" src="/img/verstka/intostroi-200x50.png" alt=""></a>
												<div class="caption">

												</div>
											</div>
										</div>

									</div>




									<?php }
									?>



								</div>
							</div>  
							<?php }
							?>




						</div>

						<!-- Left and right controls -->
						<a class="left carousel-control  hide" href="#myCarousel5" role="button" data-slide="prev">
							<span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
							<span class="sr-only">Previous</span>
						</a>
						<a class="right carousel-control hide" href="#myCarousel5" role="button" data-slide="next">
							<span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
							<span class="sr-only">Next</span>
						</a>
					</div>
				</div>



			</div>
			<li >
				&nbsp; 
				<!-- !!!!! обязательно ??? потом подправить -->
			</li>
		</div>


	</div>	</div>















	<script type="text/javascript">


	</script>











		<!-- Main jumbotron for a primary marketing message or call to action -->
		<div class="jumbotron bottom-line">

			<div class="row">

				<div class="col-md-6 col-lg-6 " style="padding-right: 0;">
					<div class="pull-right">
						<a href=""><img src="img/verstka/footl.png"></a></div>
					</div>
					<div class="col-md-6 col-lg-6" style="padding-left: 0;">

						<div class="pull-left" >
							<a href=""><img src="img/verstka/footr.png"></a></div>
						</div>
					</div>

				</div>


			</div>




		<!-- 	<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDB2kS5Y_XmTaIwC2h0uFxml1SDnrqYqnw&callback=initMap"
			async defer></script> -->
			<!--footer start from here-->
			<?php
			include_once 'includes/footer.php';
			?>